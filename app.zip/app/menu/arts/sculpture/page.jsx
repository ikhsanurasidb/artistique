import TemplatePage from "../c-page";

export default function Main() {
  return (
    <TemplatePage category="Sculpture"/>
  );
}
