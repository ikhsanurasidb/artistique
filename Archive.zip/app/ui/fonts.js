import { Kameron } from 'next/font/google';

export const kameron = Kameron({ subsets: ['latin'] });